# -----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# -----------------------------------------------------------------------------------------------------------

set_cann_package(ops_math VERSION "9.1.0")
# 编译依赖
set_cann_build_dependencies(runtime ">=8.5")
set_cann_build_dependencies(opbase ">=8.5")
set_cann_build_dependencies(metadef ">=8.5")
set_cann_build_dependencies(ge-compiler ">=8.5")
set_cann_build_dependencies(bisheng-compiler ">=8.5")
set_cann_build_dependencies(asc-devkit ">=8.5")
set_cann_build_dependencies(ge-executor ">=8.5")

# 运行时依赖
set_cann_run_dependencies(runtime ">=8.5")
set_cann_run_dependencies(opbase ">=8.5")
set_cann_run_dependencies(metadef ">=8.5")
set_cann_run_dependencies(bisheng-compiler ">=8.5")
set_cann_run_dependencies(asc-devkit ">=8.5")
set_cann_run_dependencies(ge-executor ">=8.5")
set_cann_run_dependencies(asc-tools ">=8.5")
set_cann_run_dependencies(ops-legacy ">=8.5")
